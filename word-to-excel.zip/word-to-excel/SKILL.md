---
name: word-to-excel
description: Use ONLY when the user asks to convert a Word document (.docx) into an Excel file for excel2rpy. Parse the Word narrative into a 12-column script table with proper command types. Do NOT use for general Excel/Word tasks unrelated to excel2rpy.
---

# Word to excel2rpy Excel Converter

Convert a Word document (.docx) containing a visual novel script or narrative into
an Excel file (.xlsx) that the `excel_to_rpy.py` tool can consume and convert to
Ren'Py `.rpy` script.

> **中文版**: 同目录下 `SKILL_zh.md` 为中文完整版，包含更详细的中文语境说明和实战技巧。处理中文小说时务必同时参考。

## Prerequisites

Install the required Python libraries before writing any code:

```bash
pip install python-docx openpyxl
```

- `python-docx` — read Word .docx files
- `openpyxl` — write Excel .xlsx files (already a dependency of excel2rpy)

## How to Read the Word Document

Use `python-docx` to extract content. The typical approach:

```python
from docx import Document

doc = Document("script.docx")
for para in doc.paragraphs:
    text = para.text.strip()
    if not text:
        continue
    # Parse text into commands based on patterns
```

Tables in Word are also common. Iterate them with `doc.tables`.

## Excel Format Reference (12 Columns)

The output Excel MUST follow this exact 12-column layout. Row 1 is the header.

| Col | Letter | Header | Width | Content |
|-----|--------|--------|-------|---------|
| A | 0 | 场景标签 | 16 | Label name (e.g. `start`, `chapter1`) |
| B | 1 | 指令类型 | 20 | Command from the list below |
| C | 2 | 图片/背景 | 24 | Image/bg path (e.g. `bg_classroom`) |
| D | 3 | 角色名 | 14 | Character name |
| E | 4 | 变量名 | 14 | Variable name (auto-forward-filled) |
| F | 5 | 逻辑连接 | 10 | `and` / `or` (for compound conditions) |
| G | 6 | 对话文本 | 40 | Dialogue / value / condition code |
| H | 7 | 选项文本 | 20 | Menu option display text |
| I | 8 | 跳转目标 | 16 | Jump/call target label |
| J | 9 | 音频路径 | 24 | Audio file path |
| K | 10 | 位置/特效/属性 | 22 | Transition / position / effect |
| L | 11 | 备注 | 20 | Notes (ignored in output) |

## Command Types (Column B)

Use the parsed command name (in parentheses) in column B.

### Basic Flow
| Command | When to Use |
|---------|-------------|
| `label（场景标签）` | Start every scene/chapter. Put the label name in column A. |
| `jump（跳转）` | Jump to another label. Target in column I. |
| `call（调用子场景）` | Call a subroutine. Target in column I. |
| `return（返回）` | Return from current label. |
| `menu（选择菜单）` | Start a choice menu. Follow with menu_option rows. |
| `menu_option（菜单选项）` | A choice in a menu. Text in column H, target in column I. |

### Visual
| Command | When to Use |
|---------|-------------|
| `scene（背景图）` | Set background image. Image path in column C. Effect in column K. |
| `show（显示角色）` | Show a character sprite. Character in column D, image in column C, position in column K. |
| `hide（隐藏角色）` | Hide a character. Character in column D. |

### Dialogue
| Command | When to Use |
|---------|-------------|
| `dialogue（角色对话）` | Character speaks. Name in column D, text in column G. |
| `narrator（旁白）` | Narration (no speaker). Text in column G. For centered text, add `centered` in notes (column L). |

### Audio
| Command | When to Use |
|---------|-------------|
| `play_music（播放BGM）` | Start BGM. Path in column J. |
| `stop_music（停止BGM）` | Stop music. Fadeout in column K. |
| `play_sound（播放音效）` | Play sound effect. Path in column J. |
| `voice（配音）` | Play voice clip. Path in column J. |

### Interaction
| Command | When to Use |
|---------|-------------|
| `pause（暂停等待）` | Pause. Duration (seconds) in column G. |
| `player_input（玩家输入）` | Ask player for text input. Variable name in column D, prompt in column G. |
| `window（对话框开关）` | Show/hide dialog window. Action in column G (`show`/`hide`/`auto`). |

### Defines (placed at file start)
| Command | When to Use |
|---------|-------------|
| `define_character（定义角色）` | Declare a character. Name in column D, `Character(...)` expression in column G. |
| `define_variable（定义变量）` | Declare a variable. Name in column E, initial value in column G. |
| `define_image（定义图片）` | Declare an image. Name in column E, path in column G. |

### Variables & Conditions
| Command | When to Use |
|---------|-------------|
| `variable_set（变量赋值）` | Set variable. Name in column E, value in column G. |
| `variable_change（变量增减）` | Change variable (+/-). Name in column E, delta in column G. |
| `variable_toggle（变量开关）` | Toggle boolean. Name in column E, `true`/`false` in column G. |
| `variable_eq（变量=）` | if var == value. Name in column E, value in column G. |
| `variable_ge（变量≥）` | if var >= value. Name in column E, value in column G. |
| `variable_le（变量≤）` | if var <= value. Name in column E, value in column G. |
| `variable_gt（变量>）` | if var > value. Name in column E, value in column G. |
| `variable_lt（变量<）` | if var < value. Name in column E, value in column G. |
| `$（设置变量）` | Arbitrary Python code in column G. |
| `if（条件判断）` | Traditional if. Condition in column G. |
| `elif（否则如果）` | Else-if. Condition in column G. |
| `else（否则）` | Else branch. |

### Compound Conditions (Chained `variable_*` with `and`/`or`)
To express `if score >= 80 and health > 50:`:
- Row N: `变量名=score`, `指令=variable_ge（变量≥）`, `对话文本=80`, `逻辑连接=and`
- Row N+1: `变量名=health`, `指令=variable_gt（变量>）`, `对话文本=50`, `逻辑连接`=*empty*
- An empty "逻辑连接" column terminates the chain and emits the full condition.

### Transition/Preset Chinese Terms (Column K)

Translate these Chinese terms automatically or leave as-is (the tool translates them):

**Transitions**: `溶解`→dissolve, `褪色`→fade, `闪白`→Fade(0.1,0.0,0.5,color="#FFFFFF"), `像素化`→pixellate, `横向振动`→hpunch, `纵向振动`→vpunch

**Positions**: `左边`→left, `右边`→right, `中间`→center, `真中`→truecenter, `左外`→offscreenleft, `右外`→offscreenright

Combine with space: `右边 溶解` → displays character on right with dissolve transition.

## Parsing Strategy (LLM-Native)

You are an LLM agent. **Do not** write regex parsers or pattern-matching code.
Instead, leverage your own language understanding:

### Step 1: Read the Word Document into Context

Use `python-docx` to extract ALL paragraph text and table content. Print or
return the full text to yourself so you can read and comprehend it as the
LLM you are.

```python
from docx import Document

doc = Document("story.docx")
lines = []
for para in doc.paragraphs:
    text = para.text.strip()
    if text:
        lines.append(text)

# Also read tables if present
for table in doc.tables:
    for row in table.rows:
        row_text = [cell.text.strip() for cell in row.cells]
        lines.append(" | ".join(row_text))

# Output for LLM to read
print("\n".join(lines))
```

### Step 2: Semantically Parse as the LLM

Read the extracted text and **understand it as a visual novel script** using
your own language comprehension. Identify:

- **Scene boundaries**: Any shift in time/location, chapter markers, section breaks.
  Even implicit transitions (e.g. "Meanwhile...", "The next day...") should
  become new `label` rows.
- **Who is speaking**: Track characters. A character name preceding dialogue,
  a quotation with attribution, or context clues about who is talking.
- **Pure narration/description**: Paragraphs that describe the setting,
  atmosphere, or action without any character speaking. These are `narrator`.
- **Stage directions**: Text describing "he walked in", "the door slammed",
  "music began playing" — map to `show`, `hide`, `scene`, `play_music`,
  `play_sound`, or `narrator` depending on whether it's visual/audio/atmosphere.
- **Choices/branching**: Any list of options, "what will you do?", "if you...",
  etc. becomes `menu` + `menu_option` rows.
- **Defines/character intros**: Early text introducing characters with traits
  (e.g. "小明是个高中生，性格内向") can become `define_character` if explicit
  enough, or stay as `narrator` if more narrative.

For **free-form novels** where there is no structured dialogue format:
- Each paragraph is likely a mix. Break compound paragraphs into multiple rows.
  Example: `"Hello," he said, walking into the dim room.` →
  `dialogue 他 "Hello"` + `narrator "他走进昏暗的房间"` + `scene bg_room_dim`
- Use your LLM judgment to decide the best row decomposition.

### Step 3: Build the Row List

Construct a Python list of row dictionaries. Think through each unit:

```python
rows = []
# For each logical unit:
rows.append({
    "label": "",           # A: only for label rows
    "cmd": "label（场景标签）",  # B: command
    "image": "",           # C: bg or character image
    "character": "",       # D: speaker name
    "variable": "",        # E: var name (rare in novels)
    "connect": "",         # F: and/or (rare in novels)
    "dialogue": "",        # G: spoken text / narration / value
    "option": "",          # H: menu option text
    "jump": "",            # I: jump target
    "audio": "",           # J: audio filename
    "effect": "",          # K: transition / position
    "notes": "",           # L: optional notes
})
```

**Crucial rules when building rows**:
1. Every scene starts with a `label` row. Invent English labels like `start`,
   `scene_1`, `forest_encounter`, etc.
2. After `label`, the first row is usually `scene` (background) then optionally
   `play_music`.
3. Each spoken line is one `dialogue` row. Multiple sentences from the same
   speaker can stay in one row, or split if interspersed with actions.
4. Use **forward-fill**: if the same character speaks consecutively, leave
   column D empty after the first row.
5. **Use pinyin/Latin variable names** in column D for all character references.
   E.g. `chiyou` not `池侑`. Define characters as `define chiyou = Character("池侑")`.
   See `SKILL_zh.md` "角色命名规范" for full rationale and conversion code.
6. Add empty rows between major scene blocks.
7. **Every scene must end with a `jump`** (or `return` for last scene).
   - Backgrounds: `bg_classroom`, `bg_park`, `bg_night_street`
   - Characters: use their actual names for images too
   - Audio: `bgm_tense`, `bgm_happy`, `sfx_door`
   - The user will replace these later.

### Step 4: Auto-Define Missing Characters

Before generating the Excel, scan the repository for existing character
definitions (in `game/defines.rpy`, `game/*.rpy`, and `*.xlsx` files). Compare
against characters appearing in the novel. For any undefined character, generate
`define_character（定义角色）` rows and insert them after the first `label` but
before the first `scene`.

See `SKILL_zh.md` for the complete scanning script and insertion logic.

### Step 5: Review Before Writing

Before generating the Excel, print the row list as a table preview so you can
verify the semantic mapping is correct. Ask yourself:
- Did I capture all dialogue?
- Are scene transitions properly labeled?
- Do choices have menu + menu_option pairs?
- Are characters introduced before they speak?

Make adjustments, then proceed to generate the Excel.
Create the Excel file with openpyxl:

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

wb = Workbook()
ws = wb.active
ws.title = "script"

HEADERS = [
    ("场景标签", 16), ("指令类型", 20), ("图片/背景", 24),
    ("角色名", 14), ("变量名", 14), ("逻辑连接", 10),
    ("对话文本", 40), ("选项文本", 20), ("跳转目标", 16),
    ("音频路径", 24), ("位置/特效/属性", 22), ("备注", 20),
]

# Write header row
header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
header_font = Font(name="微软雅黑", size=10, bold=True, color="FFFFFF")
thin_border = Border(
    left=Side(style="thin", color="B4C6E7"), right=Side(style="thin", color="B4C6E7"),
    top=Side(style="thin", color="B4C6E7"), bottom=Side(style="thin", color="B4C6E7"),
)
center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

for col_idx, (name, width) in enumerate(HEADERS, 1):
    cell = ws.cell(row=1, column=col_idx, value=name)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = center_align
    cell.border = thin_border
    ws.column_dimensions[get_column_letter(col_idx)].width = width

ws.row_dimensions[1].height = 24
ws.freeze_panes = "A2"

# Add data validation dropdown for command type (column B/2)
COMMAND_TYPES = [
    "label（场景标签）", "scene（背景图）", "show（显示角色）",
    "hide（隐藏角色）", "dialogue（角色对话）", "narrator（旁白）",
    "menu（选择菜单）", "menu_option（菜单选项）",
    "jump（跳转）", "call（调用子场景）", "return（返回）",
    "play_music（播放BGM）", "stop_music（停止BGM）",
    "play_sound（播放音效）", "voice（配音）",
    "pause（暂停等待）", "player_input（玩家输入）",
    "window（对话框开关）",
    "define_character（定义角色）", "define_variable（定义变量）",
    "define_image（定义图片）",
    "variable_set（变量赋值）", "variable_change（变量增减）",
    "variable_toggle（变量开关）",
    "variable_eq（变量=）", "variable_ne（变量≠）",
    "variable_gt（变量>）", "variable_ge（变量≥）",
    "variable_lt（变量<）", "variable_le（变量≤）",
    "$（设置变量）", "if（条件判断）", "elif（否则如果）", "else（否则）",
]

# For long dropdowns, use hidden helper sheet
formula = '"' + ",".join(COMMAND_TYPES) + '"'
if len(formula) <= 255:
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
else:
    _dd = wb.create_sheet("_dd_B")
    for i, cmd in enumerate(COMMAND_TYPES, 1):
        _dd.cell(row=i, column=1, value=cmd)
    dv = DataValidation(type="list", formula1=f"=_dd_B!$A$1:$A${len(COMMAND_TYPES)}", allow_blank=True)
    _dd.sheet_state = "hidden"

dv.error = "请从下拉列表选择指令类型"
dv.errorTitle = "无效指令"
dv.add("B2:B10000")
ws.add_data_validation(dv)

# Write data rows starting from row 2
for row_idx, row_data in enumerate(rows, 2):
    cell = ws.cell(row=row_idx, column=1, value=row_data.get("label", ""))
    cell = ws.cell(row=row_idx, column=2, value=row_data.get("cmd", ""))
    cell = ws.cell(row=row_idx, column=3, value=row_data.get("image", ""))
    cell = ws.cell(row=row_idx, column=4, value=row_data.get("character", ""))
    cell = ws.cell(row=row_idx, column=5, value=row_data.get("variable", ""))
    cell = ws.cell(row=row_idx, column=6, value=row_data.get("connect", ""))
    cell = ws.cell(row=row_idx, column=7, value=row_data.get("dialogue", ""))
    cell = ws.cell(row=row_idx, column=8, value=row_data.get("option", ""))
    cell = ws.cell(row=row_idx, column=9, value=row_data.get("jump", ""))
    cell = ws.cell(row=row_idx, column=10, value=row_data.get("audio", ""))
    cell = ws.cell(row=row_idx, column=11, value=row_data.get("effect", ""))
    cell = ws.cell(row=row_idx, column=12, value=row_data.get("notes", ""))
    # Apply border and alignment to each cell
    for col_idx in range(1, 13):
        cell = ws.cell(row=row_idx, column=col_idx)
        cell.border = thin_border
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.font = Font(name="微软雅黑", size=10)
        if row_idx % 2 == 0:
            cell.fill = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")

wb.save("output.xlsx")
```

## Output Naming

By default, name the output Excel file with the same stem as the input Word file
but with `.xlsx` extension. Example: `story.docx` → `story.xlsx`.

If the user specifies an output path, use that instead.

## Reference Example

This skill directory contains a real conversion example:

- `在蓝天下.docx` — the source Word document (a full free-form Chinese novel)
- `在蓝天下.xlsx` — the expected excel2rpy-compatible output

Read both files with python-docx and openpyxl to understand the expected mapping
quality.

### Key Patterns (Quick Reference)

| Pattern | Implementation |
|---------|---------------|
| Scene start | `label` with English label, then `scene` with placeholder bg name |
| Scene separation | Empty row between scene blocks |
| Character entrance | `show` + position in column K (`右边`, `左边`, `中间`) |
| Character exit | `hide` |
| Same speaker consecutive | Fill column D on first line, leave empty on subsequent |
| Flashback character | Suffixed names: `童年陈启`, `高中陈启`, `成年陈启` |
| Long narration | Split into 2-3 sentence `narrator` rows |
| Internal monologue | `narrator` |
| Dream sequences | `show` young self → `hide` back to reality |
| Emotion notes | Column L: `(紧张)`, `(回忆)`, `(梦)` |
| Parallel storylines | Separate `label` per location/POV |

> **Decision rationale**: Why these specific patterns? See `SKILL_zh.md` for detailed
> explanations of each choice (e.g. why suffix character names, why split narration,
> when to use `scene` vs `narrator` for actions).

## Important Rules

1. **One command per row** — never combine multiple actions in a single row.
2. **Empty rows separate logical blocks** — the tool uses empty rows to terminate if/menu blocks. Add an empty row between sections.
3. **Character forward-fill** — when the same character speaks consecutively, leave column D empty after the first line.
4. **Don't guess file paths** — use placeholder names like `bg_classroom`, `bgm_happy`, `char_xiaoming`. The user will fill in actual paths.
5. **Use Chinese transition/position terms** — the tool auto-translates them.
6. **Label naming** — use simple English/ASCII identifiers for labels (e.g. `start`, `choice1`, `end`). Avoid Chinese characters in labels.
7. **Always include dropdown validation** on column B so the user can edit commands in Excel.
8. **Add the "使用说明" sheet** — create a help sheet explaining the 12-column format and available commands. See the existing code's `_get_help_sheet_lines()` for reference content.

## After Generating the Excel

Inform the user:
1. The Excel file path
2. They can now use `python excel_to_rpy.py output.xlsx` to convert it to .rpy
3. They should fill in actual file paths for images and audio
4. They should review and adjust the commands if needed
