---
name: word-to-excel-zh
description: 中文版：将 Word 文档 (.docx) 转换为 excel2rpy 兼容的 Excel 表格。仅在用户要求将 Word/小说转为 Excel 脚本时使用。
---

# Word 转 excel2rpy Excel 转换器（中文版）

将包含视觉小说脚本或叙事文本的 Word 文档 (.docx) 转换为 `excel_to_rpy.py` 可消费的 Excel 文件 (.xlsx)。

## 前置依赖

```bash
pip install python-docx openpyxl
```

- `python-docx` — 读取 Word .docx 文件
- `openpyxl` — 写入 Excel .xlsx 文件（excel2rpy 已依赖）

## 角色命名规范（重要）

### 变量名 vs 显示名

Ren'Py 的 `Character` 定义包含两个名字：

```renpy
define chiyou = Character("池侑", color="#4a90d9")
#       ^变量名                    ^显示名
```

- **变量名**（D 列）：在代码中引用角色时使用，如 `chiyou "你好"`、`show chiyou`
- **显示名**（G 列）：玩家在对话框看到的名字

**必须使用拼音/英文变量名**，原因：
- Python 2 / 旧版 Ren'Py 7 对中文标识符兼容性差
- IDE 自动补全对 Unicode 支持不稳定
- 屏幕阅读器无法朗读中文变量名
- GitHub / 版本控制工具的 diff 对中文变量名显示不佳

**命名规则**：用小写拼音，不带声调，多字角色连续拼写：
| 角色 | 变量名 | G 列（表达式） |
|------|--------|---------------|
| 池侑 | `chiyou` | `Character("池侑")` |
| 尤炽 | `youchi` | `Character("尤炽")` |
| 梁原 | `liangyuan` | `Character("梁原")` |
| 童年池侑 | `tongnian_chiyou` | `Character("童年池侑")` |
| 少年梁原 | `shaonian_liangyuan` | `Character("少年梁原")` |

**Excel 中 define_character 行的写法**：
```
D 列 = chiyou          ← 变量名（拼音）
G 列 = Character("池侑")  ← 显示名（中文）
```

**关键**：如果 `define_character` 用了拼音变量名，那后续所有 `dialogue`、`show`、`hide` 行的 D 列也必须用同样的拼音。因为 Ren'Py 是通过变量名引用角色的。

### 角色名映射表生成

在解析小说时，先为每个角色创建拼音→中文的映射，然后在整份 Excel 中统一使用拼音：

```python
import re
from pypinyin import pinyin, Style  # pip install pypinyin

def to_pinyin(name: str) -> str:
    """中文角色名转拼音变量名"""
    # 处理特殊前缀：童年、高中、少年等 → tongnian_、gaozhong_、shaonian_
    prefixes = {"童年": "tongnian", "高中": "gaozhong", "少年": "shaonian",
                 "年轻": "nianqing", "小": "xiao"}
    for cn, py in prefixes.items():
        if name.startswith(cn):
            base = name[len(cn):]
            return f"{py}_{to_pinyin(base)}"
    # 普通名：拼音连续拼写
    result = ""
    for char in name:
        py_list = pinyin(char, style=Style.NORMAL)
        if py_list:
            result += py_list[0][0]
        else:
            result += char
    return result

# 构建映射表
char_map = {name: to_pinyin(name) for name in all_characters}
# {"池侑": "chiyou", "尤炽": "youchi", ...}
```

如果没有 `pypinyin`，可以让 agent 手动拼写（利用 LLM 的拼音知识），或直接用英文描述性命名。

## 读取 Word 文档

用 `python-docx` 提取全文内容到上下文中：

```python
from docx import Document

doc = Document("故事.docx")
lines = []
for para in doc.paragraphs:
    text = para.text.strip()
    if text:
        lines.append(text)

# 同时读取表格
for table in doc.tables:
    for row in table.rows:
        row_text = [cell.text.strip() for cell in row.cells]
        lines.append(" | ".join(row_text))

print("\n".join(lines))
```

## Excel 格式（12 列）

输出的 Excel 必须严格遵循 12 列布局。第 1 行为表头。

| 列 | 字母 | 表头 | 宽度 | 说明 |
|----|------|------|------|------|
| A | 0 | 场景标签 | 16 | 标签名（如 `start`, `chapter1`） |
| B | 1 | 指令类型 | 20 | 从下方指令列表中选择 |
| C | 2 | 图片/背景 | 24 | 背景/角色图片路径（如 `bg_classroom`） |
| D | 3 | 角色名 | 14 | 说话角色名称 |
| E | 4 | 变量名 | 14 | 变量名（自动前向填充） |
| F | 5 | 逻辑连接 | 10 | `and` / `or`（复合条件用） |
| G | 6 | 对话文本 | 40 | 对话 / 旁白 / 数值 |
| H | 7 | 选项文本 | 20 | 菜单选项显示文字 |
| I | 8 | 跳转目标 | 16 | 跳转/调用目标标签 |
| J | 9 | 音频路径 | 24 | 音频文件路径 |
| K | 10 | 位置/特效/属性 | 22 | 位置/转场/特效 |
| L | 11 | 备注 | 20 | 备注（不影响输出） |

## 指令类型（B 列）

### 基础流程
| 指令 | 使用场景 |
|------|----------|
| `label（场景标签）` | 开始每个场景/章节。标签名填 A 列。 |
| `jump（跳转）` | 跳到另一个标签。目标填 I 列。 |
| `call（调用子场景）` | 调用子程序。目标填 I 列。 |
| `return（返回）` | 返回当前标签。 |
| `menu（选择菜单）` | 开始选择菜单。后跟 menu_option 行。 |
| `menu_option（菜单选项）` | 菜单选项。选项文字填 H 列，目标填 I 列。 |

### 视觉
| 指令 | 使用场景 |
|------|----------|
| `scene（背景图）` | 切换背景。图片路径填 C 列，特效填 K 列。 |
| `show（显示角色）` | 显示角色。角色名填 D 列，图片填 C 列，位置填 K 列。 |
| `hide（隐藏角色）` | 隐藏角色。角色名填 D 列。 |

### 对话
| 指令 | 使用场景 |
|------|----------|
| `dialogue（角色对话）` | 角色说话。角色名填 D 列，内容填 G 列。 |
| `narrator（旁白）` | 旁白/叙述。内容填 G 列。居中文字在 L 列标注 `centered`。 |

### 音频
| 指令 | 使用场景 |
|------|----------|
| `play_music（播放BGM）` | 播放背景音乐。路径填 J 列。 |
| `stop_music（停止BGM）` | 停止音乐。淡出效果填 K 列。 |
| `play_sound（播放音效）` | 播放音效。路径填 J 列。 |
| `voice（配音）` | 播放配音。路径填 J 列。 |

### 交互
| 指令 | 使用场景 |
|------|----------|
| `pause（暂停等待）` | 暂停。秒数填 G 列。 |
| `player_input（玩家输入）` | 让玩家输入文字。变量名填 D 列，提示语填 G 列。 |
| `window（对话框开关）` | 显示/隐藏对话框。操作填 G 列（`show`/`hide`/`auto`）。 |

### 定义类（放在文件开头）
| 指令 | 使用场景 |
|------|----------|
| `define_character（定义角色）` | 声明角色。名字填 D 列，`Character(...)` 表达式填 G 列。 |
| `define_variable（定义变量）` | 声明变量。变量名填 E 列，初始值填 G 列。 |
| `define_image（定义图片）` | 声明图片。名称填 E 列，路径填 G 列。 |

### 变量与条件
| 指令 | 使用场景 |
|------|----------|
| `variable_set（变量赋值）` | 设置变量。变量名填 E 列，值填 G 列。 |
| `variable_change（变量增减）` | 修改变量。变量名填 E 列，增减量填 G 列。 |
| `variable_toggle（变量开关）` | 切换布尔。变量名填 E 列，`true`/`false` 填 G 列。 |
| `variable_eq（变量=）` | if var == value |
| `variable_ge（变量≥）` | if var >= value |
| `variable_le（变量≤）` | if var <= value |
| `variable_gt（变量>）` | if var > value |
| `variable_lt（变量<）` | if var < value |
| `$（设置变量）` | 任意 Python 代码填 G 列。 |
| `if（条件判断）` | 传统 if。条件填 G 列。 |
| `elif（否则如果）` | elif。条件填 G 列。 |
| `else（否则）` | else 分支。 |

### 复合条件（`variable_*` + `and`/`or` 链）
表达 `if score >= 80 and health > 50:`：
- 第 N 行：`变量名=score`，`指令=variable_ge（变量≥）`，`对话文本=80`，`逻辑连接=and`
- 第 N+1 行：`变量名=health`，`指令=variable_gt（变量>）`，`对话文本=50`，`逻辑连接=`*空*
- "逻辑连接"列留空即终止链并生成完整条件。

### 中文转场/位置术语（K 列）

以下中文术语会被自动翻译，可直接填中文：
- **转场**：`溶解`、`褪色`、`闪白`、`像素化`、`横向振动`、`纵向振动`
- **位置**：`左边`、`右边`、`中间`、`真中`、`左外`、`右外`
- 可组合：`右边 溶解` → 角色显示在右侧，溶解入场

## 解析策略（LLM 原生）

你是 LLM agent。**不要**写正则解析器或模式匹配代码。利用你自己的语言理解能力：

### 第一步：读取 Word 到上下文

用 `python-docx` 提取全部段落文字和表格内容。将全文打印出来供自己阅读理解。

### 第二步：用 LLM 语义解析

读取文本后，**像读小说一样理解它**，识别：

- **场景边界**：时间/地点变化，章节标记，分隔符。甚至隐式过渡（"与此同时..."、"第二天..."）都应成为新 `label`。
- **谁在说话**：角色名前缀对话、带归属的引号、或从上下文推断说话者。
- **纯叙述/描写**：描述场景、氛围、动作但无角色说话的段落 → `narrator`。
- **舞台指示**："他走进来"、"门砰地关上"、"音乐响起" → 根据是视觉/音频/氛围，映射为 `show`、`hide`、`scene`、`play_music`、`play_sound` 或 `narrator`。
- **选择/分支**：任何选项列表 → `menu` + `menu_option` 行。
- **角色介绍**：早期介绍角色特征的文字（如"小明是个高中生，性格内向"），若足够明确可用 `define_character`，否则保持 `narrator`。

**对纯小说文体**：
- 每段可能混合多种内容。将复合段落拆分为多行。
- 例：`"你好，"他说着走进昏暗的房间。` → `dialogue 他 "你好"` + `narrator "他走进昏暗的房间"` + `scene bg_room_dim`
- 用你的 LLM 判断力决定最佳的行分解方式。

### 第三步：构建行列表

构建 Python 行字典列表。逐一思考每个单元：

```python
rows = []
rows.append({
    "label": "",               # A: 仅 label 行填写
    "cmd": "label（场景标签）",  # B: 指令
    "image": "",               # C: 背景或角色图片
    "character": "",           # D: 说话角色
    "variable": "",            # E: 变量名
    "connect": "",             # F: and/or
    "dialogue": "",            # G: 对话/旁白/值
    "option": "",              # H: 菜单选项
    "jump": "",                # I: 跳转目标
    "audio": "",               # J: 音频路径
    "effect": "",              # K: 转场/位置
    "notes": "",               # L: 备注
})
```

**构建规则**：
1. 每个场景以 `label` 行开头。发明英文标签如 `start`、`scene_1`、`forest_encounter`。
2. `label` 后通常先 `scene`（设置背景），可选再 `play_music`。
3. 每句对白一个 `dialogue` 行。同一说话者的多句对白可在同一行，或被动作打断则分拆。
4. 同一角色连续说话时，第一行后 D 列留空（工具会自动前向填充）。
5. **D 列统一使用拼音变量名**（如 `chiyou`），不要直接用中文。参考上方"角色命名规范"章节。
6. 主要场景块之间加空行（空 dict `{}` 或跳过）。
7. **每个场景末尾必须加 `jump` 跳转到下一场景**，最后一个场景加 `return`：
   ```
   # 场景 A 末尾
   {"cmd": "jump（跳转）", "jump": "chapter2"},
   {""},  # 空行分隔
   # 场景 B 开始
   {"label": "chapter2", "cmd": "label（场景标签）"},
   ...
   # 最后一个场景末尾
   {"cmd": "return（返回）"},
   ```
   **为什么**：Ren'Py 的 `label` 间虽然可以"自然坠落"（fall through），但依赖隐式行为极其脆弱：
   - 一旦中间插入新 label，执行顺序全乱
   - 后期加分支时找不到显式跳转点
   - 阅读 `.rpy` 脚本时看不出场景间的流向关系
   
   **跳转命名规则**：用小写英文 + 下划线，与 label 名一致。如 `chapter1_exam` → `chapter2_prison`。
7. **不要猜测具体文件路径**——用描述性占位符：
   - 背景：`bg_classroom`、`bg_park`、`bg_night_street`
   - 角色图片：使用角色真实姓名
   - 音频：`bgm_tense`、`bgm_happy`、`sfx_door`
   - 用户后续会替换。

### 第四步：扫描仓库，自动补充角色定义

**这是关键步骤：在生成 Excel 之前，必须先找出哪些角色尚未定义。**

```python
import os, re
from pathlib import Path

def scan_defined_characters(repo_root="."):
    """扫描仓库中已有的角色定义，返回 {角色名: 来源} 字典"""
    defined = {}

    # 1. 扫描 defines.rpy
    defines_rpy = Path(repo_root) / "game" / "defines.rpy"
    if defines_rpy.exists():
        for line in defines_rpy.read_text(encoding="utf-8-sig").splitlines():
            m = re.match(r'define\s+(\w+)\s*=\s*Character', line.strip())
            if m:
                defined[m.group(1)] = f"defines.rpy"

    # 2. 扫描所有 .rpy 文件中的 define
    game_dir = Path(repo_root) / "game"
    if game_dir.is_dir():
        for rpy in game_dir.glob("**/*.rpy"):
            if rpy.name == "defines.rpy":
                continue
            for line in rpy.read_text(encoding="utf-8-sig").splitlines():
                m = re.match(r'define\s+(\w+)\s*=\s*Character', line.strip())
                if m and m.group(1) not in defined:
                    defined[m.group(1)] = f"{rpy.name}"

    # 3. 扫描所有 Excel 中的 define_character
    try:
        from openpyxl import load_workbook
        for xlsx in Path(repo_root).glob("**/*.xlsx"):
            try:
                wb = load_workbook(xlsx, data_only=True)
                for ws in wb.worksheets:
                    if ws.sheet_state == "hidden" or ws.title.startswith("_dd"):
                        continue
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        if len(row) <= 4:
                            continue
                        cmd = str(row[1] or "").strip()
                        char_name = str(row[3] or "").strip()
                        if "define_character" in cmd and char_name and char_name not in defined:
                            defined[char_name] = f"{xlsx.name}"
                wb.close()
            except Exception:
                pass
    except ImportError:
        pass

    return defined

# 执行扫描
defined_chars = scan_defined_characters(".")
print(f"已定义角色: {list(defined_chars.keys())}")
```

**对比你从小说中识别出的角色列表，找出未定义角色。注意：用拼音变量名作为 key 进行对比。如果已有定义中使用了中文变量名（如 `define 池侑`），`\w+` 正则也能匹配中文。**

```python
# novel_chars 是你从小说中识别出的所有角色中文名
novel_chars = {"池侑", "尤炽", "梁原", "陈晓", "舒湃", ...}

# 建立拼音映射
def to_pinyin(name):
    """简单拼音转换，使用 LLM 的拼音知识直接硬编码映射表"""
    pass  # 由 agent 在上下文中完成映射

char_pinyin_map = {name: to_pinyin(name) for name in novel_chars}
# {"池侑": "chiyou", "尤炽": "youchi", ...}

undefined = set()
for cn, py in char_pinyin_map.items():
    if py not in defined_chars and cn not in defined_chars:
        undefined.add((py, cn))

if undefined:
    print(f"\n以下角色未定义，将自动生成 define_character 行：")
    for py, cn in sorted(undefined):
        print(f"  + define {py} = Character('{cn}')")
```

**将未定义角色的 `define_character` 行插入到 Excel 的开头（D 列用拼音，G 列用中文显示名）：**

```python
define_rows = []
for py_name, cn_name in sorted(undefined):
    define_rows.append({
        "label": "",
        "cmd": "define_character（定义角色）",
        "image": "",
        "character": py_name,         # D 列 = 拼音变量名
        "variable": "",
        "connect": "",
        "dialogue": f'Character("{cn_name}")',  # G 列 = 中文显示名
        "option": "",
        "jump": "",
        "audio": "",
        "effect": "",
        "notes": f"自动生成 | 中文名: {cn_name}",
    })

# 插入到 label 之后、第一个 scene 之前
# 找到第一个 label 行的位置
insert_pos = 0
for i, row in enumerate(rows):
    if "label" in row.get("cmd", ""):
        insert_pos = i + 1
        break

rows = rows[:insert_pos] + define_rows + [{}] + rows[insert_pos:]
```

**为什么这一步重要**：
- `excel_to_rpy.py` 转换时会自动将 `define_character` 行写入 `defines.rpy`，但如果角色在 Excel 中根本没有定义行，就需要用户手动去别处补。
- 自动扫描 + 补全后，生成的 Excel 是**开箱可用**的——用户拿到 .xlsx 直接 `python excel_to_rpy.py script.xlsx` 就能跑。
- 避免"转换成功但运行报错 `Character 'xxx' is not defined`"的尴尬。

### 第五步：预览后生成

生成 Excel 前，打印行列表预览，检查语义映射。自问：
- 是否捕获了所有对话？
- 场景转换是否正确标注？
- 选项是否有 menu + menu_option 配对？
- 角色是否在说话前已被介绍？
- **所有角色是否都有 `define_character` 定义？**

调整后生成 Excel。

## 实战技巧

### 长篇叙述拆分

长描写段落应拆成多个 `narrator` 行，每行 1-3 句，便于阅读和维护：

```
# 差：一段 200 字的 narrator
# 好：拆成 3 个 60-70 字的 narrator 行
narrator "推开咖啡店的门，一股暖意扑面而来。"
narrator "店里灯光昏黄而温暖，角落坐着一个男生。"
narrator "他正翻着一本旧书，镜片反着光。"
```

### 闪回/回忆处理

过去时间的场景用 `show` + 特殊角色名区分：
- `童年陈启`、`高中陈启`、`成年陈启`
- 回忆结束用 `hide` 清除

### 内心独白

角色心中所想 → `narrator`，或在备注标注 `(独白)`：
```
narrator "我真的能回去吗...那个地方，已经没有我认识的人了。"  # L列: (独白)
```

### 平行剧情

不同地点/角色的故事线用独立 `label` 分隔：
```
chapter4_tanghulu       # 陈启的故事线
chapter4_youchi_side    # 陈余的故事线
```

## 生成 Excel 代码

```python
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

wb = Workbook()
ws = wb.active
ws.title = "script"

HEADERS = [
    ("场景标签", 16), ("指令类型", 20), ("图片/背景", 24),
    ("角色名", 14), ("变量名", 14), ("逻辑连接", 10),
    ("对话文本", 40), ("选项文本", 20), ("跳转目标", 16),
    ("音频路径", 24), ("位置/特效/属性", 22), ("备注", 20),
]

header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
header_font = Font(name="微软雅黑", size=10, bold=True, color="FFFFFF")
thin_border = Border(
    left=Side(style="thin", color="B4C6E7"), right=Side(style="thin", color="B4C6E7"),
    top=Side(style="thin", color="B4C6E7"), bottom=Side(style="thin", color="B4C6E7"),
)
center_align = Alignment(horizontal="center", vertical="center", wrap_text=True)

# 写入表头
for col_idx, (name, width) in enumerate(HEADERS, 1):
    cell = ws.cell(row=1, column=col_idx, value=name)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = center_align
    cell.border = thin_border
    ws.column_dimensions[get_column_letter(col_idx)].width = width

ws.row_dimensions[1].height = 24
ws.freeze_panes = "A2"

# 指令类型下拉验证
COMMAND_TYPES = [
    "label（场景标签）", "scene（背景图）", "show（显示角色）",
    "hide（隐藏角色）", "dialogue（角色对话）", "narrator（旁白）",
    "menu（选择菜单）", "menu_option（菜单选项）",
    "jump（跳转）", "call（调用子场景）", "return（返回）",
    "play_music（播放BGM）", "stop_music（停止BGM）",
    "play_sound（播放音效）", "voice（配音）",
    "pause（暂停等待）", "player_input（玩家输入）",
    "window（对话框开关）",
    "define_character（定义角色）", "define_variable（定义变量）",
    "define_image（定义图片）",
    "variable_set（变量赋值）", "variable_change（变量增减）",
    "variable_toggle（变量开关）",
    "variable_eq（变量=）", "variable_ne（变量≠）",
    "variable_gt（变量>）", "variable_ge（变量≥）",
    "variable_lt（变量<）", "variable_le（变量≤）",
    "$（设置变量）", "if（条件判断）", "elif（否则如果）", "else（否则）",
]

formula = '"' + ",".join(COMMAND_TYPES) + '"'
if len(formula) <= 255:
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
else:
    _dd = wb.create_sheet("_dd_B")
    for i, cmd in enumerate(COMMAND_TYPES, 1):
        _dd.cell(row=i, column=1, value=cmd)
    dv = DataValidation(type="list", formula1=f"=_dd_B!$A$1:$A${len(COMMAND_TYPES)}", allow_blank=True)
    _dd.sheet_state = "hidden"

dv.error = "请从下拉列表选择指令类型"
dv.errorTitle = "无效指令"
dv.add("B2:B10000")
ws.add_data_validation(dv)

# 写入数据行（从第 2 行开始）
for row_idx, row_data in enumerate(rows, 2):
    for col_idx, key in enumerate(["label", "cmd", "image", "character", "variable",
                                     "connect", "dialogue", "option", "jump", "audio",
                                     "effect", "notes"], 1):
        cell = ws.cell(row=row_idx, column=col_idx, value=row_data.get(key, ""))
        cell.border = thin_border
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.font = Font(name="微软雅黑", size=10)
        if row_idx % 2 == 0:
            cell.fill = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")

wb.save("output.xlsx")
print(f"[OK] 已输出到 output.xlsx")
```

## 参考示例

此 skill 目录内含真实转换示例：

- `在蓝天下.docx` — 完整自由格式中文小说的 Word 源文件
- `在蓝天下.xlsx` — 对应的 excel2rpy 兼容输出

执行任务时先用 python-docx 和 openpyxl 读取这两个文件，理解期望的映射质量。

### 示例中的关键模式（决策依据）

以下分析"在蓝天下.xlsx"示例中每个模式**为什么这么做**，帮助你在遇到模糊情况时做出正确判断。

---

#### 1. 场景管理：每幕 label + scene

**做了什么**：每幕以 `label` + `scene` 开头，中间用空行分隔。

**为什么**：
- Ren'Py 以 `label` 为跳转/存档的最小单位。把每个场景设为独立 label，后续想加分支跳转或存档点都无需重构。
- `scene` 紧跟 label 出现，确保场景切换立刻生效。如果把 `scene` 放在对话中间，玩家会看到上一个背景闪一下才切换——体验很差。
- 空行不仅是视觉分隔，在 `excel_to_rpy.py` 中空行会结束未闭合的 `if`/`menu` 块，防止条件泄漏到下一个场景。

**边界判断**：
- **必须新建 label**：物理位置变了（屋内→屋外）、时间跳跃（"第二天"）、POV 切换（陈启→陈余）。
- **不需要新建 label**：同一房间里走来走去、同一段对话中人物的进出。

---

#### 2. 角色命名：`童年陈启` vs `陈启`

**做了什么**：闪回中的角色叫 `童年陈启`、`高中陈启`，与当前的 `陈启` 是不同角色名。

**为什么**：
- Ren'Py 的 `show` 以角色名区分立绘层。如果用同一个名字 `陈启` 显示不同年龄的立绘，Ren'Py 会认为只是换图，不会触发新的入场特效。
- 更重要的是，不同年龄段的角色通常使用完全不同的立绘资源（画风、服装、比例均不同）。在后期美术阶段，用独立角色名可以直接对应不同的图片文件夹，策划修改时也一眼能看出哪些场景需要两套立绘。
- 回到现实时 `hide 童年陈启` 能精准清除回忆状态，不影响当前 `陈启` 的显示层。

**决策规则**：
- 外表/服装明显变化 → 新角色名（加时间前缀）
- 只是表情/动作变化 → 用同一角色名
- 不确定时：看这个角色在系统里是否需要独立立绘资源

---

#### 3. 旁白拆分：60-80 字一行

**做了什么**：长描写段落拆成多个 `narrator` 行，每行约 1-3 句。

**为什么**：
- Ren'Py 的 `narrator` 是一次性显示整行文字。200 字的段落堆在一个对话框里，玩家根本看不完就会点过去——文字是消耗品，不是装饰品。
- 拆分后的短旁白可以配合 `scene`、`show`、`pause` 等指令插入，形成"文字→画面切换→文字"的节奏。例：
  ```
  narrator "他推开店门。"
  scene bg_coffee_shop with dissolve
  narrator "暖意扑面而来，灯光昏黄而温暖。"
  ```
  如果"推开店门"和背景切换写成一行，切换会出现在文字显示之前或之后，失去同步感。
- 对话行（`dialogue`）同样遵循此原则：一句话一行。同一个人的两句话拆分后可以插入角色动作（`narrator "他低下头。"`），让剧本有"演出"节奏。

**拆分粒度**：
- 纯描写：1 个空间/氛围的完成 = 1 行
- 复合动作："他抬手→敲门→等待" = 1 行（连续动作），但"他推门→看到→走过去" = 3 行（每次换焦点）
- 内心独白：一个完整念头 = 1 行

---

#### 4. 动作描写的归属：`narrator` 还是 `scene`/`show`？

**做了什么**：大多数动作描写归为 `narrator`，只有明显的空间变换才用 `scene`/`show`。

**为什么**：
- `narrator` 是"告诉玩家发生了什么"，`scene`/`show` 是"让玩家看到变化"。
- 区别关键："这件事发生了，玩家看到的是什么画面？"
  - "他走进教室" → 如果背景已经显示教室，这就是 `narrator`（画面没变，只是描述动作）
  - "推开咖啡店的门" → 如果之前在外面，这就是 `scene bg_coffee_shop`（画面要变）
- 过度使用 `scene` 会导致 Ren'Py 频繁刷新背景层，产生闪烁且让转换衔接不自然。

**决策矩阵**：
| 描写 | 画面是否改变 | → 指令 |
|------|------------|--------|
| 他站起身 | 否（还在原地） | `narrator` |
| 他走进房间 | 是（新空间） | `scene` 或 `narrator` + 后跟 `scene` |
| 一个人出现在门口 | 是（新角色） | `show` |
| 她笑了 | 否 | `narrator`（后续可以 `show` 换表情立绘） |

---

#### 5. 角色进出时机

**做了什么**：角色出现时 `show`，消失时 `hide`，两端成对。

**为什么**：
- Ren'Py 的 sprite 层是栈式管理。不 `hide` 旧角色就加新 `show`，旧立绘会留在底层叠加，造成画面混乱。
- 场景切换（`scene`）会自动清除所有角色层，但**同一场景内**的角色切换必须手动 `hide`。
- 示例中"在蓝天下"的聚会场景：4 个角色 `show` 在屏幕四角，散场后分别 `hide`。如果漏掉一个，那个角色会在下一个场景突然出现。

**规则**：
- 场景切换（`scene`）→ 自动清除，不需要手动 `hide`
- 同一场景内角色退场 → 必须 `hide`
- 梦境/闪回中的角色 → 闪回结束必须 `hide`，否则角色会"穿越"到现实

---

#### 6. 情感标注：L 列备注的用途

**做了什么**：在 L 列标注 `(紧张)`、`(回忆)`、`(梦)`、`(独白)`。

**为什么**：
- L 列不影响代码生成，但它是 Excel 表内的人类可读元数据。策划/编剧在 Excel 里浏览时，这些标注能帮助他们快速理解每行的"情绪意图"。
- 后期配乐/配音阶段，标注可以作为参考："这一段是回忆场景，需要温暖的 BGM"。
- 做 roundtrip（.rpy → Excel → .rpy）时，这些标注会保留，实现双向同步。

**标注建议**：
| 标注 | 含义 | 何时使用 |
|------|------|----------|
| `(紧张)` | 紧张/焦虑 | 角色内心压力上升 |
| `(回忆)` | 闪回/过去 | 回忆性场景 |
| `(梦)` | 梦境 | 角色做梦/幻觉 |
| `(独白)` | 内心独白 | narrator 行是角色内心想法 |
| `(转)` | 转折 | 剧情关键转折点 |
| `(伏笔)` | 伏笔 | 后续剧情有呼应 |

---

#### 7. 平行剧情：独立 label 分隔

**做了什么**：陈启的故事线和陈余的故事线用不同 label 分隔（`chapter4_tanghulu` vs `chapter4_youchi_side`）。

**为什么**：
- Ren'Py 的 `label` 是一个可跳转的入口点。两条线独立后，编剧可以在编辑时通过 `jump` 在它们之间切换测试不同路线。
- 物理分隔让 Excel 表格的可读性大幅提升——你不会在主角的对话流中突然看到另一个城市发生的事。
- 如果后期需要做"双线选择"（玩家选择跟随陈启还是陈余），独立的 label 结构可以直接对接 `menu` 的 `jump` 目标，无需重构。

**规则**：
- 时间/空间/人物都不同 → 独立 label
- 只是同一场景的不同角度 → 同一 label 内用 `narrator` 切换

---

#### 8. 场景间的跳转连接

**做了什么**：每个场景末尾加 `jump` 行，指向下一个场景的 label；最后一个场景加 `return`。

**为什么**：
- Ren'Py 的 label 之间虽然可以"自然坠落"（不写 jump，执行完上一个 label 后自动进入下一个），但**绝对不要依赖这个行为**：
  - 隐式坠落没有文档化的执行边界，哪天 Ren'Py 更新了行为可能就断了
  - 一旦在两个 label 之间插入新场景，执行流全乱，调试时根本找不到哪出了 bug
  - 后期做分支（menu → 跳转不同线路）时，隐式坠落让你无法定位"当前场景结束后去哪"
- 显式 `jump` 让 .rpy 脚本和 Excel 表格都有了**可追踪的场景流**：任何人在任何位置都能一眼看出"A 结束后跳 B"。
- 最后一个场景用 `return`（不是 `jump`），Ren'Py 会返回到主菜单/调用方，避免死循环。

**在 Excel 中的写法**：

```
| A | B | C | D | E | F | G | H | I | J | K | L |
|---|---|---|---|---|---|---|---|---|---|---|---|
| chapter1 | label（场景标签） |     |     |     |     |     |     |     |     |     |     |
|          | scene（背景图）    | bg  |     |     |     |     |     |     |     |     |     |
| ...      | ...               |     |     |     |     |     |     |     |     |     |     |
|          | jump（跳转）       |     |     |     |     |     |     | ch2 |     |     |     |
|          |                   |     |     |     |     |     |     |     |     |     |     | ← 空行
| chapter2 | label（场景标签）  |     |     |     |     |     |     |     |     |     |     |
| ...      | ...               |     |     |     |     |     |     |     |     |     |     |
|          | return（返回）     |     |     |     |     |     |     |     |     |     |     |
```

**什么时候用 `jump` vs `return`**：
| 位置 | 指令 | 原因 |
|------|------|------|
| 每个场景结尾 | `jump` | 指向下一个 label |
| 整个脚本结尾 | `return` | 退出到主菜单 |
| 分支选项后 | `jump` | menu_option 的 I 列已隐含跳转 |
| 游戏中途结束 | `return` | 提前返回（如 bad end） |
